package edu.miu.cs472;

import java.io.PrintWriter;

public class QuizViewer {

    public QuizViewer(){

    }

    /**
     * Generate new question page and provide current score
     *
     * @param sessQuizModule
     * @param out
     * @param currQuest
     * @param error
     * @param answer
     * @return {PrintWriter}
     */
    protected PrintWriter genQuizPage(QuizModule sessQuizModule, PrintWriter out, String currQuest, boolean error, String answer) {

        out.print("<html>");
        out.print("<head>");
        out.print("	<title>NumberQuiz</title>");
        out.print("</head>");
        out.print("<body>");
        out.print("	<form method='post'>");
        out.print("		<h3>Have fun with NumberQuiz!</h3>");
        out.print("<p>Your current score is: ");
        out.print(sessQuizModule.getNumCorrect() + "</br></br>");
        out.print("<p>Guess the next number in the sequence! \n");
        out.print(currQuest + "</p>");

        out.print("<p>Your answer:<input type='text' name='txtAnswer' value='' /></p> ");

        /* if incorrect, then print out error message */
        if (error && (answer != null)) {  //REFACTOR?-- assumes answer null only when first open page
            out.print("<p style='color:red'>Your last answer was not correct! Please try again</p> ");
        }
        out.print("<p><input type='submit' name='btnNext' value='Next' /></p> ");

        out.print("</form>");
        out.print("</body></html>");

        return out;
    }

    /**
     * generate quiz over page
     * @param out
     * @return
     */
    protected PrintWriter genQuizOverPage(PrintWriter out) {
        out.print("<html> ");
        out.print("<head >");
        out.print("<title>NumberQuiz is over</title> ");
        out.print("</head> ");
        out.print("<body> ");
        out.print("<p style='color:green'>Congrats! The number quiz is over!</p>	</body> ");
        out.print("</html> ");
        return out;
    }

}
